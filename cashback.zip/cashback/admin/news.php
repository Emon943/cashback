<?php
    
	include('menu.php');
	
	echo "<br>";
	echo "<br>";
	echo "<br>";
	echo "<br>";
	echo "<br>";
	
?>	
   <div align="center">
	
	   <h2 style="color:red">This site is in under construction</h2>
    </div>
	
<?php
     
	echo "<br>";
	echo "<br>";
	echo "<br>";
	echo "<br>";
	echo "<br>"; 
	
	include('footer.php');


?>